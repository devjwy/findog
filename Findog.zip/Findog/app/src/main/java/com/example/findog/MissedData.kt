package com.example.findog

import java.util.Date

class MissedData (
    var imgurl:String="",
    var place: String="",
    var axis: String="",
    var date: String="",
    var content:String="",
    var type :String="",
    var emb : String=""
){}