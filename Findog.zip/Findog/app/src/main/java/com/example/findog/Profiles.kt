package com.example.findog

import android.graphics.drawable.Drawable

data class Profiles(val imageUrl: Int, val date: String)
//data class Profiles(val image:Drawable?, val date: String)