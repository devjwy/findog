package com.example.findog

class MissingData (
    var imageUrl:String="",
    var place: String="",
    var axis: String="",
    var date: String="",
    var description:String="",
    var type :String=""
){}